package servlets;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddLibrarianForm")
public class AddLibrarianForm extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Add Librarian Form</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("</head>");
		out.println("<body>");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/elibrary_db","root","root");
			PreparedStatement stat=con.prepareStatement("insert into e_librarian values(?,?,?,?,?);");
			stat.setInt(1,Integer.parseInt(request.getParameter("id1")));
			stat.setString(2,request.getParameter("name1"));
			stat.setString(3, request.getParameter("password1"));
			stat.setString(4, request.getParameter("email1"));
			stat.setInt(5,Integer.parseInt(request.getParameter("mobile1")));
			stat.executeUpdate();
			out.println("<h3>Librarian Added Successfully</h3>");
			con.close();
			
		}
		catch(Exception e)
		{
		out.println(e);	
		}
		request.getRequestDispatcher("navadmin.html").include(request, response);
		out.println("<div class='container'>");
		request.getRequestDispatcher("addlibrarianform.html").include(request, response);
		out.println("</div>");
		
		
		
		request.getRequestDispatcher("footer.html").include(request, response);
		out.close();

	}

}
